import google.generativeai as genai

# =====================================
# CONFIGURAÇÃO DA API GEMINI
# =====================================

GEMINI_API_KEY = "AQ.Ab8RN6IF2d8RZ28LDJaRinUbEX-S4XNDF3GDHlHAPuPo2-YKZg"

genai.configure(api_key=GEMINI_API_KEY)

modelo = genai.GenerativeModel("gemini-2.5-flash")

# =====================================
# DADOS DA LOJA
# =====================================

produtos = [
    {"nome": "Notebook Gamer", "preco": 4999.90},
    {"nome": "Mouse Gamer", "preco": 149.90},
    {"nome": "Teclado Mecânico", "preco": 299.90},
    {"nome": "Monitor Gamer", "preco": 1299.90}
]

carrinho = []

# =====================================
# IA
# =====================================

def perguntar_ia():

    pergunta = input("\nDigite sua pergunta: ")

    lista_produtos = ""

    for produto in produtos:
        lista_produtos += f"- {produto['nome']} - R$ {produto['preco']:.2f}\n"

    prompt = f"""
Você é a assistente virtual da Loja Virtual IA.

Produtos disponíveis:

{lista_produtos}

Responda sempre em português.
Se perguntarem sobre produtos, utilize apenas a lista acima.

Cliente:
{pergunta}
"""

    try:
        resposta = modelo.generate_content(prompt)
        print("\nIA:")
        print(resposta.text)
    except Exception as erro:
        print("\nErro:", erro)

# =====================================
# PRODUTOS
# =====================================

def ver_produtos():

    while True:

        print("\n========== PRODUTOS ==========")

        for i, produto in enumerate(produtos, start=1):
            print(f"{i} - {produto['nome']} - R$ {produto['preco']:.2f}")

        print("0 - Voltar")

        opcao = input("\nEscolha um produto: ")

        if opcao == "0":
            break

        if opcao.isdigit():

            indice = int(opcao) - 1

            if 0 <= indice < len(produtos):

                carrinho.append(produtos[indice])

                print(f"\n{produtos[indice]['nome']} adicionado ao carrinho!")

# =====================================
# CARRINHO
# =====================================

def ver_carrinho():

    print("\n========== CARRINHO ==========")

    if len(carrinho) == 0:
        print("Carrinho vazio.")
        return

    total = 0

    for produto in carrinho:

        print(f"- {produto['nome']} - R$ {produto['preco']:.2f}")

        total += produto["preco"]

    print("------------------------------")
    print(f"Total: R$ {total:.2f}")

# =====================================
# ADMINISTRAÇÃO
# =====================================

def administracao():

    print("\n======= NOVO PRODUTO =======")

    nome = input("Nome: ")

    try:
        preco = float(input("Preço: "))
    except ValueError:
        print("Preço inválido.")
        return

    produtos.append({
        "nome": nome,
        "preco": preco
    })

    print("\nProduto cadastrado com sucesso!")

# =====================================
# MENU
# =====================================

while True:

    print("\n==============================")
    print("      LOJA VIRTUAL COM IA")
    print("==============================")
    print("1 - Ver Produtos")
    print("2 - Carrinho")
    print("3 - Assistente IA")
    print("4 - Administração")
    print("0 - Sair")

    opcao = input("\nEscolha uma opção: ")

    if opcao == "1":
        ver_produtos()

    elif opcao == "2":
        ver_carrinho()

    elif opcao == "3":
        perguntar_ia()

    elif opcao == "4":
        administracao()

    elif opcao == "0":
        print("\nObrigado por utilizar nossa loja!")
        break

    else:
        print("\nOpção inválida.")