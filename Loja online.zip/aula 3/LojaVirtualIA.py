import tkinter as tk
from tkinter import messagebox, scrolledtext
import google.generativeai as genai

# =====================================
# CONFIGURAÇÃO DA API GEMINI
# =====================================

GEMINI_API_KEY = "AQ.Ab8RN6IF2d8RZ28LDJaRinUbEX-S4XNDF3GDHlHAPuPo2-YKZg"

genai.configure(api_key=GEMINI_API_KEY)

modelo = genai.GenerativeModel("gemini-2.5-flash")

CONTEXTO = """
Você é a assistente virtual da Loja Virtual IA.

Seu trabalho é atender os clientes de forma educada.

Você pode:
- Responder dúvidas sobre produtos.
- Explicar formas de pagamento.
- Informar sobre entregas.
- Explicar política de troca.
- Recomendar produtos.
- Sempre responder em português.

Caso o cliente faça uma pergunta que não seja relacionada à loja,
responda educadamente e tente trazer a conversa para assuntos da loja.
"""


def perguntar_ia(pergunta):
    try:
        prompt = CONTEXTO + "\n\nCliente: " + pergunta
        resposta = modelo.generate_content(prompt)
        return resposta.text
    except Exception as erro:
        return f"Erro ao conectar com a IA:\n\n{erro}"


# =====================================
# TELA DA IA
# =====================================

def abrir_ia():

    janela_ia = tk.Toplevel()
    janela_ia.title("Assistente IA")
    janela_ia.geometry("600x500")

    conversa = scrolledtext.ScrolledText(janela_ia, width=70, height=20)
    conversa.pack(pady=10)

    entrada = tk.Entry(janela_ia, width=60)
    entrada.pack(pady=5)

    def enviar():

        pergunta = entrada.get()

        if pergunta == "":
            return

        conversa.insert(tk.END, "Você: " + pergunta + "\n\n")

        resposta = perguntar_ia(pergunta)

        conversa.insert(tk.END, "IA: " + resposta + "\n\n")
        conversa.see(tk.END)

        entrada.delete(0, tk.END)

    botao = tk.Button(
        janela_ia,
        text="Enviar",
        command=enviar
    )

    botao.pack(pady=10)


# =====================================
# OUTRAS TELAS
# =====================================

def abrir_produtos():
    messagebox.showinfo(
        "Produtos",
        "Tela de Produtos\n\n(Em desenvolvimento)"
    )


def abrir_carrinho():
    messagebox.showinfo(
        "Carrinho",
        "Tela do Carrinho\n\n(Em desenvolvimento)"
    )


def abrir_pedidos():
    messagebox.showinfo(
        "Pedidos",
        "Tela de Pedidos\n\n(Em desenvolvimento)"
    )


def abrir_admin():
    messagebox.showinfo(
        "Administração",
        "Painel Administrativo\n\n(Em desenvolvimento)"
    )


# =====================================
# HUB PRINCIPAL
# =====================================

janela = tk.Tk()
janela.title("Loja Virtual com IA")
janela.geometry("500x520")
janela.resizable(False, False)

titulo = tk.Label(
    janela,
    text="LOJA VIRTUAL COM IA",
    font=("Arial", 18, "bold")
)

titulo.pack(pady=20)

subtitulo = tk.Label(
    janela,
    text="Hub Principal",
    font=("Arial", 12)
)

subtitulo.pack()

btn_produtos = tk.Button(
    janela,
    text="🛒 Produtos",
    width=25,
    height=2,
    command=abrir_produtos
)

btn_produtos.pack(pady=8)

btn_carrinho = tk.Button(
    janela,
    text="🛍 Carrinho",
    width=25,
    height=2,
    command=abrir_carrinho
)

btn_carrinho.pack(pady=8)

btn_pedidos = tk.Button(
    janela,
    text="📦 Pedidos",
    width=25,
    height=2,
    command=abrir_pedidos
)

btn_pedidos.pack(pady=8)

btn_ia = tk.Button(
    janela,
    text="🤖 Assistente IA",
    width=25,
    height=2,
    command=abrir_ia
)

btn_ia.pack(pady=8)

btn_admin = tk.Button(
    janela,
    text="⚙ Administração",
    width=25,
    height=2,
    command=abrir_admin
)

btn_admin.pack(pady=8)

btn_sair = tk.Button(
    janela,
    text="Sair",
    bg="red",
    fg="white",
    width=15,
    command=janela.destroy
)

btn_sair.pack(pady=25)

janela.mainloop()