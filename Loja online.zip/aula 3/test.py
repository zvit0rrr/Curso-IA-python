import google.generativeai as genai

# =====================================
# CONFIGURAÇÃO DO GEMINI
# =====================================

GEMINI_API_KEY = "AQ.Ab8RN6IF2d8RZ28LDJaRinUbEX-S4XNDF3GDHlHAPuPo2-YKZg"

genai.configure(api_key=GEMINI_API_KEY)

modelo = genai.GenerativeModel("gemini-2.5-flash")

# =====================================
# DADOS DA LOJA
# =====================================

produtos = [
    {"nome": "Notebook Gamer", "preco": 4999.90},
    {"nome": "Mouse Gamer", "preco": 149.90},
    {"nome": "Teclado Mecânico", "preco": 299.90},
    {"nome": "Monitor Gamer", "preco": 1299.90}
]

carrinho = []
pedidos = []

# =====================================
# ASSISTENTE IA
# =====================================

def perguntar_ia():

    pergunta = input("\nDigite sua pergunta: ")

    lista_produtos = ""

    for produto in produtos:
        lista_produtos += f"- {produto['nome']} - R$ {produto['preco']:.2f}\n"

    prompt = f"""
Você é a assistente virtual da Loja Virtual IA.

Produtos disponíveis:

{lista_produtos}

Informações da loja

Telefone: (11) 4002-8922
WhatsApp: (11) 99999-9999
Email: suporte@lojavirtualia.com

Responda sempre em português.

Caso perguntem sobre produtos utilize somente os produtos da lista.

Caso perguntem sobre contato utilize os contatos acima.

Pergunta:

{pergunta}
"""

    try:

        resposta = modelo.generate_content(prompt)

        print("\n==============================")
        print("ASSISTENTE IA")
        print("==============================")
        print(resposta.text)

    except Exception as erro:

        print("Erro:", erro)

# =====================================
# PRODUTOS
# =====================================

def ver_produtos():

    while True:

        print("\n========== PRODUTOS ==========")

        for i, produto in enumerate(produtos, start=1):

            print(f"{i} - {produto['nome']} - R$ {produto['preco']:.2f}")

        print("\n0 - Voltar")

        opcao = input("\nEscolha um produto: ")

        if opcao == "0":
            break

        if opcao.isdigit():

            indice = int(opcao) - 1

            if 0 <= indice < len(produtos):

                carrinho.append(produtos[indice])

                print("\nProduto adicionado ao carrinho!")

            else:

                print("Produto inválido.")

# =====================================
# CARRINHO
# =====================================

def ver_carrinho():

    print("\n========== CARRINHO ==========")

    if len(carrinho) == 0:

        print("Carrinho vazio.")
        return

    total = 0

    for i, produto in enumerate(carrinho, start=1):

        print(f"{i} - {produto['nome']} - R$ {produto['preco']:.2f}")

        total += produto["preco"]

    print("-----------------------------")
    print(f"TOTAL: R$ {total:.2f}")

# =====================================
# SUPORTE
# =====================================

def suporte():

    while True:

        print("\n========== SUPORTE ==========")

        print("1 - Conversar com a IA")
        print("2 - Meios de Contato")
        print("0 - Voltar")

        opcao = input("\nEscolha: ")

        if opcao == "1":

            perguntar_ia()

        elif opcao == "2":

            print("\n========== CONTATOS ==========")
            print("Telefone : (11) 4002-8922")
            print("WhatsApp : (11) 99999-9999")
            print("Email    : suporte@lojavirtualia.com")
            print("Endereço : Rua das Flores, 123")
            print("Cidade   : São Paulo - SP")
            print("Horário  : Seg-Sex 08h às 18h")

        elif opcao == "0":

            break

        else:

            print("Opção inválida.")

# =====================================
# ADMINISTRAÇÃO
# =====================================

def administracao():

    print("\n======= CADASTRAR PRODUTO =======")

    nome = input("Nome do produto: ")

    try:

        preco = float(input("Preço: "))

    except:

        print("Preço inválido.")
        return

    produtos.append({
        "nome": nome,
        "preco": preco
    })

    print("\nProduto cadastrado com sucesso!")

    # =====================================
# REMOVER PRODUTO DO CARRINHO
# =====================================

def remover_produto():

    if len(carrinho) == 0:
        print("\nCarrinho vazio.")
        return

    print("\n======= REMOVER PRODUTO =======")

    for i, produto in enumerate(carrinho, start=1):
        print(f"{i} - {produto['nome']} - R$ {produto['preco']:.2f}")

    print("0 - Cancelar")

    opcao = input("\nEscolha o produto: ")

    if opcao == "0":
        return

    if opcao.isdigit():

        indice = int(opcao) - 1

        if 0 <= indice < len(carrinho):

            removido = carrinho.pop(indice)

            print(f"\n{removido['nome']} removido do carrinho!")

        else:

            print("Produto inválido.")

# =====================================
# FINALIZAR COMPRA
# =====================================

def finalizar_compra():

    if len(carrinho) == 0:

        print("\nCarrinho vazio.")
        return

    total = 0

    print("\n========== COMPRA ==========")

    for produto in carrinho:

        print(f"- {produto['nome']} - R$ {produto['preco']:.2f}")

        total += produto["preco"]

    print("-----------------------------")
    print(f"TOTAL: R$ {total:.2f}")

    print("\nForma de pagamento")

    print("1 - PIX")
    print("2 - Cartão")
    print("3 - Boleto")

    pagamento = input("\nEscolha: ")

    if pagamento == "1":
        forma = "PIX"

    elif pagamento == "2":
        forma = "Cartão"

    elif pagamento == "3":
        forma = "Boleto"

    else:
        print("Forma de pagamento inválida.")
        return

    pedidos.append({
        "produtos": carrinho.copy(),
        "total": total,
        "pagamento": forma
    })

    carrinho.clear()

    print("\nCompra realizada com sucesso!")

# =====================================
# HISTÓRICO DE PEDIDOS
# =====================================

def ver_pedidos():

    print("\n========== PEDIDOS ==========")

    if len(pedidos) == 0:

        print("Nenhum pedido realizado.")
        return

    for numero, pedido in enumerate(pedidos, start=1):

        print(f"\nPedido {numero}")

        for produto in pedido["produtos"]:

            print(f"- {produto['nome']}")

        print(f"Pagamento: {pedido['pagamento']}")
        print(f"Total: R$ {pedido['total']:.2f}")

# =====================================
# MENU PRINCIPAL
# =====================================

while True:

    print("\n===================================")
    print("      LOJA VIRTUAL COM IA")
    print("===================================")

    print("1 - Ver Produtos")
    print("2 - Carrinho")
    print("3 - Suporte")
    print("4 - Administração")
    print("5 - Histórico de Pedidos")
    print("0 - Sair")

    opcao = input("\nEscolha uma opção: ")

    if opcao == "1":

        ver_produtos()

    elif opcao == "2":

        while True:

            print("\n========== CARRINHO ==========")

            print("1 - Visualizar Carrinho")
            print("2 - Remover Produto")
            print("3 - Finalizar Compra")
            print("0 - Voltar")

            escolha = input("\nEscolha: ")

            if escolha == "1":

                ver_carrinho()

            elif escolha == "2":

                remover_produto()

            elif escolha == "3":

                finalizar_compra()

            elif escolha == "0":

                break

            else:

                print("Opção inválida.")

    elif opcao == "3":

        suporte()

    elif opcao == "4":

        administracao()

    elif opcao == "5":

        ver_pedidos()

    elif opcao == "0":

        print("\nObrigado por utilizar nossa Loja Virtual!")
        break

    else:

        print("\nOpção inválida.")